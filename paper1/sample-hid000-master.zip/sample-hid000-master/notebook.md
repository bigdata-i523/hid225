# Logistic

* 08/21/17 Read the entire class overview section 

# Theory

* 08/22/17 - 08/23/17 Read and watched all videso in the Theory Introduction section

# Practice

* 08/24/17 Bought Raspberry PI
* 08/25/17 Enabled Python 2 and 3 via pyenv on OSX

# Writing

* 08/26/17 Installed and Learned aquamacs
* 00/01/17 Installed and Learned jabref
